/*
 * Copyright (c) 2019, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef QOS_INIT_H_M3_V30__
#define QOS_INIT_H_M3_V30__

void qos_init_m3_v30(void);

#endif	/* QOS_INIT_H_M3_V30__ */
