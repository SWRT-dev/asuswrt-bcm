This is a prototype loosely based on the SPCI Alpha and SPRT pre-alpha
specifications. Any interface / platform API introduced for this is subject to
change as it evolves.
